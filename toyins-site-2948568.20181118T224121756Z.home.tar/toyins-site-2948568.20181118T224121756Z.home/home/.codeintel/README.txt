
This is a database for the Code Intelligence system (a
subsystem of Komodo). Do NOT modify anything in here unless
you know what you are doing.

See http://www.komodoide.com/ for details.
